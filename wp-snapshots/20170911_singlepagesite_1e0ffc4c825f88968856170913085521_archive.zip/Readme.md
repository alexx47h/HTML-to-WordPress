Layouts:
1. source code - startbootstrap-modern-business.zip (directory - mytheme, DB is hidden);
2. Blog layout (directory - 2spsite).

Path to the themes (one theme = one site):
/wp-content/themes

Deployment using the plugin "Duplicator".